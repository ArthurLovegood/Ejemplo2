package com.arturss.PrimerMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerMvcApplication.class, args);
	}

}
